package com.sarah.videdressing.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.sarah.videdressing.models.Articles;

public interface ArticleRepo extends CrudRepository<Articles, Long> {
	//retrieve all instances of all listings
	List<Articles> findAll();
}
