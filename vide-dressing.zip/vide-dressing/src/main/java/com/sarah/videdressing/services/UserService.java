package com.sarah.videdressing.services;

import java.util.List;
import java.util.Optional;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;

import com.sarah.videdressing.models.LoginUser;
import com.sarah.videdressing.models.Users;
import com.sarah.videdressing.repositories.UserRepo;

@Service
public class UserService {
	// Auto DI
	@Autowired
	private UserRepo userRepo;

	// crud methods

	// 1- returns all users
	public List<Users> allUsers() {
		return userRepo.findAll();
	}

	// 2- find an user by id
	public Users findUser(Long id) {
		Optional<Users> optionalUser = userRepo.findById(id);
		if (optionalUser.isPresent()) {
			return optionalUser.get();
		} else {
			return null;
		}
	}

	// 3- Register
	public Users register(Users newUser, BindingResult result) {
		// check if a user exists
		Optional<Users> optionalUser = userRepo.findByEmail(newUser.getEmail());
		if (optionalUser.isPresent()) {
			result.rejectValue("email", "registrationError", "This Email is already Taken!");
		}
		// Check if passwords matches
		if (!newUser.getPassword().equals(newUser.getConfirm())) {
			result.rejectValue("password", "registrationError", "Passwords must match !");
		}
		if (result.hasErrors()) {
			return null;
		} else {
			//make the original password is securely hashed
			String hashed = BCrypt.hashpw(newUser.getPassword(), BCrypt.gensalt());
			//store the hashed password
			newUser.setPassword(hashed);
			// store user to the data base
			return userRepo.save(newUser);
		}
	}

	// 4- login
	public Users login(LoginUser newLogin, BindingResult result) {
		Optional<Users> potentialUser = userRepo.findByEmail(newLogin.getEmail());
		// check if potentialUser does have a value or not
		if (!potentialUser.isPresent()) {
			result.rejectValue("email", "loginError", "Invalid credentials!");
		} else {
			Users user = potentialUser.get();
			// BCRYPT hashing library -> check password and validation
			if (!BCrypt.checkpw(newLogin.getPassword(), user.getPassword())) {
				result.rejectValue("password", "loginError", "Invalid credentials!");
			}
			if (result.hasErrors()) {
				return null;
			} else {
				return user;
			}
		}
		return null;

	}
	
	//read all notes 
	public List<Users> allNote(){
		return userRepo.findAll();
	}
	
	//create note
	public Users createNote(Users note) {
		return userRepo.save(note);
	}
}
