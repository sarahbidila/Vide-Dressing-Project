package com.sarah.videdressing.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sarah.videdressing.models.Articles;
import com.sarah.videdressing.repositories.ArticleRepo;

@Service
public class ArticleService {
@Autowired 
private ArticleRepo articleRepo;

//read all articles 
public List<Articles> allArticles(){
	return articleRepo.findAll();
}

//create article
public Articles createArticle(Articles article) {
	return articleRepo.save(article);
}

//read only one article
public Articles findArticles(Long id) {
	Optional<Articles> savedArticles = articleRepo.findById(id);
	if(savedArticles.isPresent()) {
	return savedArticles.get();
	}else {
		return null;
		}
	}
//update an article
public Articles updateArticle(Articles articles) {
	return articleRepo.save(articles);
}
//delete an article
public void deleteArticle(Long id) {
	articleRepo.deleteById(id);
}
//likes
public void likeArticle(Articles articles) {
	articles.setLikes(articles.getLikes() + 1);
    articleRepo.save(articles);
}
}
