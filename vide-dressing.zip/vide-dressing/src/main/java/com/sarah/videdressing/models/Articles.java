package com.sarah.videdressing.models;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
@Entity
@Table(name = "Articles")
public class Articles {
		// MEMEBER VARIABLES
				@Id
				@GeneratedValue(strategy = GenerationType.IDENTITY)
				private Long id;
				
				@NotEmpty(message="Artile name is required")
			    @Size(min=3, max=20, message="Article name must be between 3 and 20 characters")
				private String name;
				
				@Lob
			    private byte[] image; 
				
				@NotNull(message="Price should not be empty!")
				private Long price;
				
				@DateTimeFormat(pattern="MM-dd-yyyy")
			    private Date CreatedOn;
				
////				--- M to 1---
//				@ManyToOne(fetch = FetchType.LAZY)
//				@JoinColumn(name = "user_id")
//				private Users user;
				
				@PrePersist
			    protected void onCreate(){
			        this.CreatedOn = new Date();
			    }
				//GETTERS AND SETTERS AND CONSTRUCTOR
				public Articles() {}
				
				
				public Long getId() {
					return id;
				}

				public void setId(Long id) {
					this.id = id;
				}

				public String getName() {
					return name;
				}

				public void setName(String name) {
					this.name = name;
				}

				public byte[] getImage() {
					return image;
				}

				public void setImage(byte[] image) {
					this.image = image;
				}

				public Long getPrice() {
					return price;
				}

				public void setPrice(Long price) {
					this.price = price;
				}

				public Date getCreatedOn() {
					return CreatedOn;
				}

				public void setCreatedOn(Date createdOn) {
					CreatedOn = createdOn;
				}
}
