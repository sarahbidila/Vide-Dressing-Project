package com.sarah.videdressing.models;

import java.math.BigDecimal;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
@Entity
@Table(name = "Articles")
public class Articles {
		// MEMEBER VARIABLES
				@Id
				@GeneratedValue(strategy = GenerationType.IDENTITY)
				private Long id;
				
				@NotEmpty
			    @Size(min=3, max=20, message="Article name must be between 3 and 20 characters")
				private String name;
				
				@NotEmpty
			    @Size(min=3, max=200, message="Article description must be between 3 and 100 characters")
				private String description;
				
				@NotNull(message = "Price should not be empty!")
				@DecimalMin(value = "0.0")
				@DecimalMax(value = "1000.0")
				private BigDecimal price;
				
				@DateTimeFormat(pattern="MM-dd-yyyy")
			    private Date CreatedOn;
				
				private int likes;
//				--- M to 1---
				@ManyToOne(fetch = FetchType.LAZY)
				@JoinColumn(name = "user_id")
				private Users user;
				
				@PrePersist
			    protected void onCreate(){
			        this.CreatedOn = new Date();
			    }
				//GETTERS AND SETTERS AND CONSTRUCTOR
				public Articles() {}
				
				
				public Long getId() {
					return id;
				}

				public void setId(Long id) {
					this.id = id;
				}

				public String getName() {
					return name;
				}

				public void setName(String name) {
					this.name = name;
				}

				public BigDecimal getPrice() {
					return price;
				}

				public void setPrice(BigDecimal price) {
					this.price = price;
				}

				public Date getCreatedOn() {
					return CreatedOn;
				}

				public void setCreatedOn(Date createdOn) {
					CreatedOn = createdOn;
				}
				
				public Users getUser() {
					return user;
				}
				public void setUser(Users user) {
					this.user = user;
				}
				public String getDescription() {
					return description;
				}
				public void setDescription(String description) {
					this.description = description;
				}
				public int getLikes() {
					return likes;
				}
				public void setLikes(int likes) {
					this.likes = likes;
				}
}
