package com.sarah.videdressing.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.sarah.videdressing.models.LoginUser;
import com.sarah.videdressing.models.Users;
import com.sarah.videdressing.services.UserService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
public class MainController {

	//Auto dependency injection
	@Autowired
	private UserService userServ;
	
	// Display Route to main registration page
	// this handles both registration and login
	@GetMapping("/")
	public String main(Model model) {
		// addition of a newUser to the model object
		model.addAttribute("newUser", new Users());
		// addition of an User to the model object
		model.addAttribute("newLogin", new LoginUser());
		return "register_log.jsp";
	}
	@GetMapping("/home")
	public String home(	HttpSession session) {
		

		return "home.jsp";
	}
	
	// Action Route to submit a register form
	@PostMapping("/register")
	public String register(@Valid @ModelAttribute("newUser") Users newUser, BindingResult result, Model model,
			HttpSession session) {
		Users user = userServ.register(newUser, result);
		if (result.hasErrors()) {
			// stay on the same page and display errors
			model.addAttribute("newLogin", new LoginUser());
			return "register_log.jsp";
		} else {
			session.setAttribute("userID", newUser.getId());
			// redirection to home if successful
			return "redirect:/home";
		}
	}
	// Action route to login
	@PostMapping ("/login")
	public String login(@Valid @ModelAttribute("newLogin") LoginUser newLogin,
			BindingResult result, Model model,HttpSession session) {
		Users user = userServ.login(newLogin, result);
		if(result.hasErrors()) {
			// stay in the same page and display errors
			model.addAttribute("newUser", new Users());
			return "register_log.jsp";
		}else {
			// save the user in session and redirect to home page
			session.setAttribute("userID", user.getId());
			return "redirect:/home";
		}
	}
	
	//logout
	@GetMapping ("/logout")
	public String logout (HttpSession session) {
		// close the session
		session.invalidate();
		// redirecting to main registration page
		return "redirect:/";
	}
	
}
