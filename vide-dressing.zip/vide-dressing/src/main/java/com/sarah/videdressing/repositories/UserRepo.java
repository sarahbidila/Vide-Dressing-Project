package com.sarah.videdressing.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.sarah.videdressing.models.Users;

public interface UserRepo extends CrudRepository<Users, Long> {
	//retrieve all instances of all users
	List<Users> findAll();
	//find a single instance of the Users entity by its email attribute
	Optional<Users> findByEmail(String email);
}
