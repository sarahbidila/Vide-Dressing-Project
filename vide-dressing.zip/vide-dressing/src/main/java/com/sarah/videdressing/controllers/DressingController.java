package com.sarah.videdressing.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sarah.videdressing.models.Articles;
import com.sarah.videdressing.models.Users;
import com.sarah.videdressing.services.ArticleService;
import com.sarah.videdressing.services.UserService;

import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;

@Controller
public class DressingController {
	// Auto DI
		@Autowired
		private ArticleService articleServ;
		@Autowired
		private UserService userServ;
		// display route to home
		@GetMapping("/home")
		public String homeLog(@ModelAttribute("articles") Articles articles, HttpSession session, Model model) {
			Long id = (Long) session.getAttribute("userID");
			if (id == null) {
				return "redirect:/";
			} else {
				// Pass the user Loged in to the dashboard file
				Users loggedinUser = userServ.findUser(id);
				model.addAttribute("user", loggedinUser);
				List<Articles> allArticles = articleServ.allArticles();
				model.addAttribute("allArticles", allArticles);
				List<Users> allUsers = userServ.allUsers();
				model.addAttribute("allUsers", allUsers);
				return "home.jsp";
			}
		}
		
		// CREATE
		// display route to articles/add-dressing => to create an article
		@GetMapping("/articles/add-dressing")
		public String createArticle(@ModelAttribute("article") Articles article, HttpSession session, Model model) {
			Long id = (Long) session.getAttribute("userID");
			if (id == null) {
				return "redirect:/";
			} else {
				// retrieving an user from the user service
				// fetch the user entity
				Users loggedinUser = userServ.findUser(id);
				// addition to the model
				model.addAttribute("user", loggedinUser);
				List<Articles> allArticles = articleServ.allArticles();
				model.addAttribute("allArticles", allArticles);
				return "new.jsp";
			}
		}
		
		//Action Route to sumbit the new article
		@PostMapping("/articles")
		public String makeArticles(@Valid @ModelAttribute("article") Articles articles, BindingResult res) {
			if (res.hasErrors()) {
				return "new.jsp";
			} else {

				articleServ.createArticle(articles);
			}
			return "redirect:/home";
		}
		
		//the like Post function
		@PostMapping("/articles/like")
		public String likeArticle(@RequestParam("id") Long id) {
		    // Retrieve the article from the database
		    Articles articles = articleServ.findArticles(id);

		    if (articles != null) {
		        // Increment the like count
		        int currentLikeCount = articles.getLikes();
		        articles.setLikes(currentLikeCount + 1);

		        // Save the updated article in the database
		        articleServ.createArticle(articles);
		    }

		    // Redirect back to the home page
		    return "redirect:/home";
		}
		
		// UPDATE
		// Display route after update
		@GetMapping("/articles/{id}")
		public String edit(@PathVariable("id") Long id, Model model) {

			Articles articles = articleServ.findArticles(id);
			model.addAttribute("articles", articles);
			return "edit.jsp";
		}

		// Action route after update
		@PostMapping("/articles/updateArticles/{id}")
		public String update(@PathVariable("id") Long id, @Valid @ModelAttribute("articles") Articles articles,
				BindingResult result) {
			// Update logic
			if (result.hasErrors()) {
				return "edit.jsp";
			} else {
				articleServ.updateArticle(articles);
				return "redirect:/home";
			}
		}
		
		// DELETE
		@DeleteMapping("/articles/{id}")
		public String destroy(@PathVariable("id") Long id) {
			articleServ.deleteArticle(id);
			return "redirect:/home";
		}

		
			@GetMapping("/viewProfile")
			public String viewProfile(HttpSession session, Model model) {
				Long id = (Long) session.getAttribute("userID");
				if (id == null) {
					return "redirect:/";
				} else {
					// retrieving an user from the user service
					// fetch the user entity
					Users loggedinUser = userServ.findUser(id);
					// addition to the model
					model.addAttribute("user", loggedinUser);
					return "view-profile.jsp";
				}
			}
		}
